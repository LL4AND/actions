#!/bin/sh
npx --yes azurite -L -l ./temp_azurite -d ./temp_azurite/debug.log