#pragma once

#include "ggml-cpu-traits.h"
#include "ggml.h"

// GGML internal header

ggml_backend_buffer_type_t ggml_backend_cpu_aarch64_buffer_type(void);
